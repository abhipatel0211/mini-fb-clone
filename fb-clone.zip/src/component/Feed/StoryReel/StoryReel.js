import React from 'react';
import "./StoryReel.css";
import Story from './Story';


const StoryReel = () => {
  return (
      <div className='StoryReel'>
          {/* Story */}
          <Story image="https://shorturl.at/aBIX6" profileSrc="https://shorturl.at/aBIX6" title="Abhi - Darshil"/>
          {/* Story */}
          <Story image="https://shorturl.at/aBIX6" profileSrc="https://shorturl.at/aBIX6" title="Abhi - Darshil"/>
          {/* Story */}
          <Story image="https://shorturl.at/aBIX6" profileSrc="https://shorturl.at/aBIX6" title="Abhi - Darshil"/>
          {/* Story */}
          <Story image="https://shorturl.at/aBIX6" profileSrc="https://shorturl.at/aBIX6" title="Abhi - Darshil"/>
          {/* Story */}
          <Story image="https://shorturl.at/aBIX6" profileSrc="https://shorturl.at/aBIX6" title="Abhi - Darshil"/>
    </div>
  )
}

export default StoryReel;